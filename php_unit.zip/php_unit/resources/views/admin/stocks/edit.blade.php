@extends('layouts.app')
@section('content')
{!! Form::model($stock, [
        'method' => 'PATCH',
        'url' => ['stocks', $stock->id],
        'class' => 'form-horizontal',
    ]) !!}<div class="container">
    <div class="form-group {{ $errors->has('name') ? 'has-error' : ''}}">
    {!! Form::label('name', 'Name: ', ['class' => 'col-sm-4 control-label']) !!}
    <div class="col-sm-4 form-group {{ $errors->has('name') ? 'has-error' : 'has-success'}}">
    {!! Form::text('name', $stock->name, ['class' => 'form-control']) !!}
    </div>
    </div>
    <div class="form-group {{ $errors->has('price') ? 'has-error' : ''}}">
    {!! Form::label('price', 'Price: ', ['class' => 'col-sm-4 control-label']) !!}
    <div class="col-sm-4 form-group {{ $errors->has('price') ? 'has-error' : 'has-success'}}">
    {!! Form::text('price', $stock->price, ['class' => 'form-control']) !!}
    </div>
    </div>
    <button class="btn btn-primary">Update</button>
</div>
@endsection
