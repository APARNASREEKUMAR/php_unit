@extends('layouts.app')
@section('content')
<div class="container">
<table class="table table-responsive" id="userlist" > 
    
    <thead>
    <th>Id</th>
    <th>Name</th>
    <th>Price</th>
    <th>Actions</th>
    </thead>
    @foreach($stocks as $stock )
    <tbody>
    <td>{{ $stock->id }}</td>
    <td>{{ $stock->name }}</td>
    <td>{{ $stock->price }}</td>
    <td>
    {!! Form::open(['method'  => 'DELETE', 'route' => ['stocks.destroy', $stock->id]]) !!}
    <button class="btn btn-danger" type="submit">Delete</button>
    {!! Form::close() !!}
    </td>
   </tbody>
    @endforeach
    </table>
</div>
@endsection