@extends('layouts.app')
@section('content')
{!! Form::open(['url' => 'stocks', 'class' => 'form-horizontal','method' => 'post', 'files'=>'true']) !!}
<div class="container">
    <div class="form-group {{ $errors->has('name') ? 'has-error' : ''}}">
    {!! Form::label('name', 'Name: ', ['class' => 'col-sm-4 control-label']) !!}
    <div class="col-sm-4 form-group {{ $errors->has('name') ? 'has-error' : 'has-success'}}">
    {!! Form::text('name', null, ['class' => 'form-control']) !!}
    </div>
    </div>
    <div class="form-group {{ $errors->has('price') ? 'has-error' : ''}}">
    {!! Form::label('price', 'Price: ', ['class' => 'col-sm-4 control-label']) !!}
    <div class="col-sm-4 form-group {{ $errors->has('price') ? 'has-error' : 'has-success'}}">
    {!! Form::text('price', null, ['class' => 'form-control']) !!}
    </div>
    </div>
 <button class="btn btn-primary">Submit</button>   
</div>
@endsection