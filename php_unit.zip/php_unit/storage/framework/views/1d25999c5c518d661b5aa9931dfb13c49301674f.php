<?php $__env->startSection('content'); ?>
<?php echo Form::open(['url' => 'stocks', 'class' => 'form-horizontal','method' => 'post', 'files'=>'true']); ?>

<div class="container">
    <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('name', 'Name: ', ['class' => 'col-sm-4 control-label']); ?>

    <div class="col-sm-4 form-group <?php echo e($errors->has('name') ? 'has-error' : 'has-success'); ?>">
    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

    </div>
    </div>
    <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
    <?php echo Form::label('price', 'Price: ', ['class' => 'col-sm-4 control-label']); ?>

    <div class="col-sm-4 form-group <?php echo e($errors->has('price') ? 'has-error' : 'has-success'); ?>">
    <?php echo Form::text('price', null, ['class' => 'form-control']); ?>

    </div>
    </div>
 <button class="btn btn-primary">Submit</button>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/php_unit/resources/views/admin/stocks/create.blade.php ENDPATH**/ ?>