<?php $__env->startSection('content'); ?>
<div class="container">
<table class="table table-responsive" id="userlist" > 
    
    <thead>
    <th>Id</th>
    <th>Name</th>
    <th>Price</th>
    <th>Actions</th>
    </thead>
    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
    <td><?php echo e($stock->id); ?></td>
    <td><?php echo e($stock->name); ?></td>
    <td><?php echo e($stock->price); ?></td>
    <td>
    <?php echo Form::open(['method'  => 'DELETE', 'route' => ['stocks.destroy', $stock->id]]); ?>

    <button class="btn btn-danger" type="submit">Delete</button>
    <?php echo Form::close(); ?>

    </td>
   </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/php_unit/resources/views/admin/stocks/index.blade.php ENDPATH**/ ?>