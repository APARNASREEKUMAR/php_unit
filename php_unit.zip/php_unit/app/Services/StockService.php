<?php

namespace App\Services;

use Illuminate\Http\Request;
use App\Repositories\StockRepository;

class StockService 
{   
    /**
     * @var StockRepository $stockRepository
     */
    private $stockRepository;
    
    /**
     * StockService constructor.
     * Initialize object/instance for classes.
     *
     * @param StockRepository $stockRepository
     */
    public function __construct(StockRepository $stockRepository)
    {
        $this->stockRepository = $stockRepository;
    }
    
    /**
     * Find Details of a particular Stock
     *
     * @return \Illuminate\Http\Response
     */
    public function findStock(string $id) 
    {
        return  $this->stockRepository->findStock($id);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getAllStocks()
    {
        return $this->stockRepository->getAllStocks();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createStock($request)
    {
        $inputData = $request->all();

        return $this->stockRepository->createStock($inputData);
    }

    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateStock(Request $request, $id)
    {
        $inputData = $request->all();
        
        return $this->stockRepository->updateStock($inputData,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteStock($id)
    {
        return  $this->stockRepository->deleteStock($id);
    }
}
