<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use App\Repositories\Contracts\StockRepositoryInterface;
use App\Stock;

class StockRepository implements StockRepositoryInterface  
{    
     /**
     * Method to get all Stocks 
     *
     * @return \Illuminate\Http\Response
     */
    public function getAllStocks()
    {
        return Stock::all();
    }

    /**
     * Method to create the Stock 
     *
     * @return \Illuminate\Http\Response
     */
    public function createStock(array $inputData)
    {
       return Stock::create($inputData);
    }

    /**
     * Display a specified Stock
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function findStock($id)
    {
        return Stock::find($id);
    }

    /**
     * Update the specified stock detail.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function UpdateStock(array $inputData, $id)
    {
        return Stock::find($id)->update($inputData);
    }
    
    /**
     * Remove the specified Stock detail.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteStock($id)
    {
        return Stock::find($id)->delete();
    }
}
