<?php

namespace App\Repositories\Contracts;

use Illuminate\Http\Request;

interface StockRepositoryInterface 
{
    public function getAllStocks();
    public function createStock(array $inputData);
    public function findStock($id);
    public function updateStock(array $inputData,$id);
    public function deleteStock($id);
}
