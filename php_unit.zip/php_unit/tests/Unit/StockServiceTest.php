<?php

namespace Tests\Unit;

use Tests\TestCase;
use Mockery;
use App\Repositories\StockRepository;
use Illuminate\Foundation\Testing\RefreshDatabase;

class StockServiceTest extends TestCase
{
    private $stockService;
    const name = 'value';
    const ROOMS = 'rooms';
    public function setUp():void
    {
        parent::setUp();
        $this->mockStockRepository = \Mockery::mock(StockRepository::class);
        $this->stockService = New \App\Services\StockService($this->mockStockRepository);
        $this->mockName = 'Stock Tester';
        $this->mockPrice = '100';
    }
    /**
     * Test Stock Creation Service
     *
     * @return void
     */
    public function testStockCreateService()
    {
        $addAttributes = [
            'name' => $this->mockName,
            'price' => $this->mockPrice
        ];

        $this->mockStockRepository
            ->shouldReceive('createStock')
            ->once()
            ->with($addAttributes)
            ->andReturn(\Mockery::mock(Stock::class))
            ->getMock();

        $response = $this->stockService->createStock(collect($addAttributes));

        // $this->assertNull($response);
        $this->assertTrue($response);
    }

    
}
